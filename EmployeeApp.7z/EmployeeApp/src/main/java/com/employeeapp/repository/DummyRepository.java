package com.employeeapp.repository;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.employeeapp.literals.ApplicationLiterals;
import com.employeeapp.model.Activity;
import com.employeeapp.model.Employee;

@Component
public class DummyRepository {
	
	/**
	 * This represent the Activity table data.
	 * 
	 * Activity Table - ActivityId(Primary Key), Name(varchar), StartTime(timestamp), ActivityDuration(int) and EmpId (As Foreign Key)
	 */
	private List<Activity> activities;
	
	/**
	 * This represent the Employee table data 
	 * 
	 * Employee Table - EmpId(primary Key), Name(Varchar)
	 */
	private List<Employee> employees;
	
	public DummyRepository(){
		
		employees=new ArrayList<Employee>();
		activities=new ArrayList<Activity>();
		
		employees.add(new Employee(1, "Shyam"));
		employees.add(new Employee(2, "Ram"));
		employees.add(new Employee(3, "Rahul"));
		employees.add(new Employee(4, "Gaurav"));
		employees.add(new Employee(5, "Mohan"));
		employees.add(new Employee(6, "Pyare"));
		employees.add(new Employee(7, "Priya"));
		employees.add(new Employee(8, "Divya"));
		employees.add(new Employee(9, "Dilip"));
		employees.add(new Employee(10, "Shilpi"));
		
		Time time1= new Time(1, 20, 20);
		Time time2= new Time(5, 00, 00);
		Time time3= new Time(3, 20, 20);
		Time time4= new Time(1, 50, 20);
		Time time5= new Time(2, 20, 20);
		
		activities.add(new Activity(1, ApplicationLiterals.GAMEMOOD, time2, 20, 1));
		activities.add(new Activity(2, ApplicationLiterals.LOGIN, time1, 50, 1));
		activities.add(new Activity(3, ApplicationLiterals.LOGOUT, time2, 8, 1));
		activities.add(new Activity(4, ApplicationLiterals.LUNCHBREAK, time2, 30, 1));
		
		activities.add(new Activity(5, ApplicationLiterals.GAMEMOOD, time3, 10, 2));
		activities.add(new Activity(6, ApplicationLiterals.LOGIN, time1, 50, 2));
		activities.add(new Activity(7, ApplicationLiterals.LOGOUT, time2, 8, 3));
		activities.add(new Activity(8, ApplicationLiterals.LUNCHBREAK, time2, 30, 3));
		
		activities.add(new Activity(9, ApplicationLiterals.LOGIN, time2, 50, 10));
		activities.add(new Activity(10, ApplicationLiterals.NAPTIME, time1, 40, 10));
		activities.add(new Activity(11, ApplicationLiterals.TEABREAK, time2, 6, 10));
		activities.add(new Activity(12, ApplicationLiterals.LUNCHBREAK, time2, 3, 10));
		
		activities.add(new Activity(13, ApplicationLiterals.TEABREAK, time5, 20, 4));
		activities.add(new Activity(14, ApplicationLiterals.LOGOUT, time4, 20, 5));
		activities.add(new Activity(15, ApplicationLiterals.LUNCHBREAK, time4, 20, 6));
		activities.add(new Activity(16, ApplicationLiterals.TEABREAK, time5, 20, 6));
		
		activities.add(new Activity(17, ApplicationLiterals.LOGIN, time3, 20, 7));
		activities.add(new Activity(18, ApplicationLiterals.LOGOUT, time2, 20, 8));
		activities.add(new Activity(19, ApplicationLiterals.NAPTIME, time1, 20, 8));
		activities.add(new Activity(20, ApplicationLiterals.GAMEMOOD, time2, 20, 9));
		
	}

	public List<Activity> getActivities() {
		return activities;
	}

	
	public List<Employee> getEmployees() {
		return employees;
	}

	
	

}
