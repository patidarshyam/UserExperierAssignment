package com.employeeapp.dao;

import java.util.List;
import com.employeeapp.model.EmployeeActivity;
import com.employeeapp.model.Statistics;

public interface EmployeeDao {
	
	public List<EmployeeActivity> getTodaysActivity();
	
	public List<Statistics> getAllEmployeesLast7DayStatistics();

}
