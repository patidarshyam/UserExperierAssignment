package com.employeeapp.daoimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.employeeapp.dao.EmployeeDao;
import com.employeeapp.model.Activity;
import com.employeeapp.model.EmployeeActivity;
import com.employeeapp.model.Statistics;
import com.employeeapp.model.SuperActivity;
import com.employeeapp.repository.DummyRepository;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	DummyRepository dummyRepository;

	public List<EmployeeActivity> getTodaysActivity() {
		/*
		 * SELECT EMPID, STARTTIME, ACTIVITYNAME FROM ACTIVITY WHERE STARTTIME < NOW() + INTERVAL 0 DAY
		 */
		//NEED ONE ROWMAPPER TO MAKE THIS RESULTS INTO EMPLOYEE OBJECT OF EMPLOYEEACITVITY LIST.
		
		List<Activity> activities=dummyRepository.getActivities();
		Map<Integer, List<SuperActivity>> map = (Map<Integer, List<SuperActivity>>) new HashMap<Integer,List<SuperActivity>>();
		List<EmployeeActivity> employeeActivities=new ArrayList<EmployeeActivity>();
		
		for (Activity activity : activities) {
			int key = activity.getEmpId();
			List<SuperActivity> updatedActivities=null;
			if(map.containsKey(key)){
				updatedActivities= map.get(key);
				SuperActivity tempact=new SuperActivity();
				tempact.setTime(activity.getTime());
				tempact.setName(activity.getName());
				updatedActivities.add(tempact); //THIS ACTIVITY OBJECT CONTAINS DETAILS ACCORDING TO OUR REQUIREMENT
				map.put(key, updatedActivities);
			}else{
				updatedActivities=new ArrayList<SuperActivity>();
				SuperActivity tempact=new SuperActivity();
				tempact.setTime(activity.getTime());
				tempact.setName(activity.getName());
				updatedActivities.add(tempact);
				map.put(key, updatedActivities);
			}
		}
		
		//adding data to EmployeeActivity object;
		for(Map.Entry<Integer, List<SuperActivity>> entry:map.entrySet()){
			employeeActivities.add(new EmployeeActivity(entry.getKey(), entry.getValue()));			
		}
		
		System.out.println("DAO- getTodaysActivity");
		
		return employeeActivities;
	}

	public List<Statistics> getAllEmployeesLast7DayStatistics() {
		//THIS WILL RETURN ACTIVITYNAME: OCCURANCE COUNT IN LAST 7 DAYS
		/*
		 * SELECT  COUNT(ACTID), ACTIVITYNAME FROM ACTIVITY WHERE STARTTIME < NOW() + INTERVAL -7 DAY GROUP BY ACTIVITYNAME;
		 */
		
		System.out.println("DAO- getAllEmployeesLast7DayStatistics");
		
		//NEED ONE ROWMAPPER.
		List<Activity> activities=dummyRepository.getActivities();
		Map<String, Integer> map = new HashMap<String ,Integer>();
		List<Statistics> statistics=new ArrayList<Statistics>();
		int count=0;
		
		for (Activity activity : activities) {
			String key = activity.getName();
			if(map.containsKey(key)){
				int tempCount=map.get(key);
				tempCount++;
				map.put(key, tempCount);
			}else{
				count=1;
				map.put(key, count);
			}
		}
		
		//adding data to Statistics object;
				for(Map.Entry<String ,Integer> entry:map.entrySet()){
					statistics.add(new Statistics(entry.getKey(), entry.getValue()));			
				}
		
		return statistics;
	}

}
