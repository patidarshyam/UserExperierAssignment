package com.employeeapp.service;

import java.util.List;

import com.employeeapp.model.EmployeeActivity;
import com.employeeapp.model.Statistics;

public interface EmployeeService {
	
	public List<EmployeeActivity> getTodaysActivity();
	
	public List<Statistics> getAllEmployeesLast7DayStatistics();

}
