package com.employeeapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employeeapp.model.AllDetails;
import com.employeeapp.model.EmployeeActivity;
import com.employeeapp.model.Statistics;
import com.employeeapp.service.EmployeeService;
@RestController
public class EmployeeRestController {

	@Autowired
	private EmployeeService employeeService;
	

	
	/*@GetMapping("/test")
	public String test(){
		return "test";
	}*/
	/**
	 * This method produce output which contains activity and occurrence count list
	 * which is AllEmployeesLast7DayStatistics
	 * @return
	 */
	@GetMapping("/employeesActivities7")
	public List<Statistics> getAllEmployeesLast7DayStatistics(){
		
		return employeeService.getAllEmployeesLast7DayStatistics();
	}
	
	/**
	 * This method produce output which contains employee wise activities list
	 * which is TodaysActivities
	 * @return
	 */
	@GetMapping("/employeeActivities")
	public List<EmployeeActivity> getTodaysActivities(){
		
		return employeeService.getTodaysActivity();
	}
	/**
	 * This method produce output in the GET REST ENDPOINT expected format
	 * both -AllEmployeesLast7DayStatistics and TodaysActivities
	 * @return
	 */
	@GetMapping("/allDetails")
	public AllDetails getDetailsFromBoth(){
		AllDetails allDetails=new AllDetails();
		allDetails.setEmployeeActivities(employeeService.getTodaysActivity());
		allDetails.setStatistics(employeeService.getAllEmployeesLast7DayStatistics());
		
		return allDetails;
	}
}