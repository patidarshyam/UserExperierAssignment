package com.employeeapp.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeapp.dao.EmployeeDao;
import com.employeeapp.model.EmployeeActivity;
import com.employeeapp.model.Statistics;
import com.employeeapp.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao employeeDao;

	public List<EmployeeActivity> getTodaysActivity() {
		
		return employeeDao.getTodaysActivity();
	}

	public List<Statistics> getAllEmployeesLast7DayStatistics() {
		
		return employeeDao.getAllEmployeesLast7DayStatistics();
	}

}
