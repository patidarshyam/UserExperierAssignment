package com.employeeapp.literals;

public class ApplicationLiterals {

	public static final String LOGIN="LOGIN";
	public static final String LOGOUT="LOGOUT";
	public static final String TEABREAK="TEABREAK";
	public static final String LUNCHBREAK="LUNCHBREAK";
	public static final String GAMEMOOD="GAMEMOOD";
	public static final String NAPTIME="NAPTIME";
	
	
}
