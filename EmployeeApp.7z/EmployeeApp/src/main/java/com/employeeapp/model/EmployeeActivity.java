package com.employeeapp.model;

import java.util.List;

public class EmployeeActivity {

	private int empId;
	
	private List<SuperActivity> activities;
	
	public EmployeeActivity() {	}

	public EmployeeActivity(int empId, List<SuperActivity> activities) {
		super();
		this.empId = empId;
		this.activities = activities;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public List<SuperActivity> getActivities() {
		return activities;
	}

	public void setActivities(List<SuperActivity> activities) {
		this.activities = activities;
	}
	
	
}
