package com.employeeapp.model;

import java.sql.Time;

public class SuperActivity {

	private String name;
	
	private Time time;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}


}
