package com.employeeapp.model;

import java.util.List;

public class AllDetails {
	
	List<Statistics> statistics;

	List<EmployeeActivity> employeeActivities;
	
	public AllDetails() {
		// TODO Auto-generated constructor stub
	}

	public List<Statistics> getStatistics() {
		return statistics;
	}

	public void setStatistics(List<Statistics> statistics) {
		this.statistics = statistics;
	}

	public List<EmployeeActivity> getEmployeeActivities() {
		return employeeActivities;
	}

	public void setEmployeeActivities(List<EmployeeActivity> employeeActivities) {
		this.employeeActivities = employeeActivities;
	}
	
	
}
