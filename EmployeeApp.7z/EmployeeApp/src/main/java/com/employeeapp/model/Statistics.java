package com.employeeapp.model;

public class Statistics {

	private String activityName;
	
	private int occurance;
	
	public Statistics(){
		
	}
	

	public Statistics(String activityName, int occurance) {
		super();
		this.activityName = activityName;
		this.occurance = occurance;
	}


	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public int getOccurance() {
		return occurance;
	}

	public void setOccurance(int occurance) {
		this.occurance = occurance;
	}
	
	
}
