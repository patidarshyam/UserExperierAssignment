package com.employeeapp.model;

import java.sql.Time;

public class Activity extends SuperActivity {

	private int activitiId;
	
	private int duration;

	//Only Used as table data
	private int EmpId;
	
	public int getEmpId() {
		return EmpId;
	}


	public Activity(){}

	public Activity(int activitiId, String name, Time time, int duration, int empId) {
		super();
		this.activitiId = activitiId;
		this.setName(name);
		this.setTime(time);
		this.duration = duration;
		this.EmpId = empId;
	}

	public int getActivitiId() {
		return activitiId;
	}

	public void setActivitiId(int activitiId) {
		this.activitiId = activitiId;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	
}
