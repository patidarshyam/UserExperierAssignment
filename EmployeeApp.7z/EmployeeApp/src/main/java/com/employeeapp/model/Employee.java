package com.employeeapp.model;

import java.util.List;

public class Employee {

	private int empId;
	
	private String name;
	
	private List<Activity> activities;
	
	public Employee(){}
	

	public int getEmpId() {
		return empId;
	}

	public Employee(int empId, String name) {
		super();
		this.empId = empId;
		this.name = name;
	}
	



	public List<Activity> getActivities() {
		return activities;
	}


	public void setActivities(List<Activity> activities) {
		this.activities = activities;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
